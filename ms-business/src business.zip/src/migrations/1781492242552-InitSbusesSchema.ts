import { MigrationInterface, QueryRunner } from "typeorm";

export class InitSbusesSchema1781492242552 implements MigrationInterface {
    name = 'InitSbusesSchema1781492242552'

    public async up(queryRunner: QueryRunner): Promise<void> {
        // Tabla grupo — nuevos campos
        await queryRunner.query(`ALTER TABLE \`grupo\` ADD \`esPublico\` tinyint NOT NULL DEFAULT 0`);
        await queryRunner.query(`ALTER TABLE \`grupo\` ADD \`imagen\` varchar(255) NULL`);
        await queryRunner.query(`ALTER TABLE \`grupo\` ADD \`creadorAuthId\` varchar(255) NULL`);
        await queryRunner.query(`ALTER TABLE \`grupo\` ADD \`bloqueados\` text NULL`);
        await queryRunner.query(`ALTER TABLE \`grupo\` MODIFY \`fechaCreacion\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP`);

        // Tabla grupo_persona — nuevos campos
        await queryRunner.query(`ALTER TABLE \`grupo_persona\` ADD \`rol\` varchar(255) NOT NULL DEFAULT 'miembro'`);
        await queryRunner.query(`ALTER TABLE \`grupo_persona\` ADD \`fechaUnion\` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`grupo_persona\` DROP COLUMN \`fechaUnion\``);
        await queryRunner.query(`ALTER TABLE \`grupo_persona\` DROP COLUMN \`rol\``);
        await queryRunner.query(`ALTER TABLE \`grupo\` MODIFY \`fechaCreacion\` datetime NOT NULL`);
        await queryRunner.query(`ALTER TABLE \`grupo\` DROP COLUMN \`bloqueados\``);
        await queryRunner.query(`ALTER TABLE \`grupo\` DROP COLUMN \`creadorAuthId\``);
        await queryRunner.query(`ALTER TABLE \`grupo\` DROP COLUMN \`imagen\``);
        await queryRunner.query(`ALTER TABLE \`grupo\` DROP COLUMN \`esPublico\``);
    }
}
