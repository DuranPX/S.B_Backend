import { MigrationInterface, QueryRunner } from "typeorm";

export class InitSbusesSchema1781719672988 implements MigrationInterface {
    name = 'InitSbusesSchema1781719672988'

    public async up(
        queryRunner: QueryRunner
    ): Promise<void> {

        await queryRunner.query(`
      ALTER TABLE \`grupo\`
      ADD COLUMN \`invitacionesPendientes\`
      TEXT NULL
    `);

    }

    public async down(
        queryRunner: QueryRunner
    ): Promise<void> {

        await queryRunner.query(`
      ALTER TABLE \`grupo\`
      DROP COLUMN \`invitacionesPendientes\`
    `);
    }
}
