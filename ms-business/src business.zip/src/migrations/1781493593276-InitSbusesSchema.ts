import { MigrationInterface, QueryRunner } from "typeorm";

export class InitSbusesSchema1781493593276 implements MigrationInterface {
    name = 'InitSbusesSchema1781493593276'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`grupo\` MODIFY \`imagen\` LONGTEXT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE \`grupo\` MODIFY \`imagen\` varchar(255) NULL`);
    }
}
